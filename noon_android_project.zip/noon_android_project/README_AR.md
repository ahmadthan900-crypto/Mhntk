# مشروع نون — تطبيق Android + سيرفر الكمبيوتر

## محتويات المشروع
- `android/`: تطبيق Android Native مكتوب بـ Kotlin.
- `backend/`: سيرفر Flask وقواعد SQLite المنفصلة وواجهة JSON API.
- `.github/workflows/build-apk.yml`: يبني APK تلقائياً على GitHub Actions.

## 1) تشغيل السيرفر على Windows
1. ثبّت Python 3.11 أو أحدث على الكمبيوتر، وفعّل خيار Add Python to PATH.
2. افتح مجلد `backend`.
3. شغّل `run_windows.bat`.
4. اترك نافذة السيرفر مفتوحة. الموقع المحلي يكون على `http://127.0.0.1:5000`.

## 2) ربط الهاتف بالكمبيوتر
1. اجعل الهاتف والكمبيوتر على شبكة Wi-Fi نفسها.
2. على Windows افتح CMD واكتب `ipconfig`.
3. ابحث عن IPv4 Address تحت Wi-Fi، مثال `192.168.1.5`.
4. افتح `android/app/src/main/java/com/noon/app/MainActivity.kt`.
5. غيّر `apiBase` إلى `http://عنوان-الكمبيوتر:5000/api/v1`.
6. اسمح لـ Python/المنفذ 5000 في جدار حماية Windows للشبكة الخاصة فقط.
7. لا تستخدم `localhost` في التطبيق على هاتف حقيقي؛ فهو يشير إلى الهاتف نفسه.

> هذه النسخة تسمح بالاتصال داخل شبكة Wi-Fi. للوصول من خارج المنزل تحتاج نفقاً آمناً أو استضافة، والأفضل استخدام HTTPS. لا تفتح منفذ السيرفر مباشرة للإنترنت.

## 3) فتح تطبيق Android
1. نزّل Android Studio وثبّته.
2. من Android Studio اختر Open.
3. اختر مجلد `android` الموجود داخل المشروع.
4. انتظر Gradle Sync، ثم شغّل على محاكي أو هاتف مع تفعيل USB debugging.

## 4) إنشاء APK من Android Studio
من القائمة: Build > Build Bundle(s) / APK(s) > Build APK(s).
ستجد النسخة التجريبية في:
`android/app/build/outputs/apk/debug/app-debug.apk`

## 5) بناء APK من GitHub
1. أنشئ حساباً في GitHub.
2. أنشئ مستودعاً جديداً (New repository) باسم `noon-platform`.
3. ارفع **محتويات هذا المجلد** إلى المستودع، بحيث يظهر مجلد `android` و`backend` و`.github` في الصفحة الرئيسية.
4. افتح تبويب Actions.
5. اختر `Build Noon APK` ثم Run workflow، أو ارفع أي تعديل داخل `android/` ليبدأ البناء تلقائياً.
6. بعد انتهاء البناء بنجاح افتح نتيجة التشغيل، وانزل إلى Artifacts.
7. نزّل `noon-debug-apk.zip` وفك ضغطه؛ ستجد `app-debug.apk`.

## ملاحظات مهمة
- GitHub يبني التطبيق فقط؛ لا يشغّل Flask ولا يستضيف قواعد البيانات.
- يجب أن يبقى الكمبيوتر والسيرفر يعملين حتى يتصل التطبيق بهما.
- التطبيق الحالي نسخة أولية Native: تسجيل/إنشاء حساب، جلسة دخول، عرض الهوايات وفهرس الفيديوهات، وتسجيل الخروج.
- إدارة المحتوى ورفع الفيديوهات تبقى في لوحة الويب الموجودة في السيرفر. تشغيل الفيديو داخل التطبيق وإشعارات الهاتف والرسائل والمنشورات تحتاج مراحل تطوير لاحقة.
- لا تضع كلمات مرور أو مفاتيح خاصة في GitHub. عند نشر التطبيق للناس، استخدم HTTPS.


## إعداد رابط Cloudflare الحالي
تم ضبط تطبيق Android على الرابط الحالي:
`https://jewelry-catalyst-asin-preventing.trycloudflare.com/api/v1`

هذا رابط Quick Tunnel مؤقت؛ إذا تغيّر عند تشغيل cloudflared مرة أخرى، حدّث قيمة `apiBase` في `android/app/src/main/java/com/noon/app/MainActivity.kt` ثم أعد بناء APK. يجب إبقاء Flask ونافذة cloudflared مفتوحتين أثناء استخدام التطبيق.

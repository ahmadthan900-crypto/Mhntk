# واجهة API لتطبيق نون

شغّل السيرفر من مجلد backend عبر `run_windows.bat`.
فحص السيرفر: `GET /api/v1/health`

## المسارات
- `POST /api/v1/register` JSON: `name, phone, age, password`
- `POST /api/v1/login` JSON: `phone, password`
- `GET /api/v1/me` مع `Authorization: Bearer TOKEN`
- `GET /api/v1/hobbies` مع Bearer token
- `GET /api/v1/videos` مع Bearer token
- `POST /api/v1/logout` مع Bearer token

كلمات المرور لا تُخزّن كنص صريح؛ يستمر استخدام Werkzeug password hashing.
رموز API تحفظ في قاعدة الحسابات كـ SHA-256 hash، وليس كنص الرمز.

هذه نسخة أولية: التطبيق يعرض الحساب والهوايات وفهرس الفيديوهات.
رفع الفيديوهات وإدارة المنصة ما زالا من لوحة الويب الحالية، وتشغيل الفيديو داخل
تطبيق Android يحتاج مرحلة ربط مشغل الوسائط بواجهة بث محمية.

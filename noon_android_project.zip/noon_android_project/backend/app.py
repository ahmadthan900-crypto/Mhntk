import os, re, time, hmac, sqlite3, secrets, uuid
from functools import wraps
from flask import (Flask, g, render_template, request, redirect, url_for,
                   session, flash, send_from_directory, abort)
from markupsafe import Markup
from werkzeug.security import generate_password_hash, check_password_hash
from werkzeug.utils import secure_filename

BASE = os.path.dirname(os.path.abspath(__file__))
DATA = os.path.join(BASE, "data")
UPLOADS = os.path.join(BASE, "uploads")
os.makedirs(DATA, exist_ok=True)
os.makedirs(UPLOADS, exist_ok=True)

# Separate databases: identity, media catalogue, community content, and site settings.
DBS = {
    "accounts": os.path.join(DATA, "accounts.db"),
    "videos": os.path.join(DATA, "videos.db"),
    "community": os.path.join(DATA, "community.db"),
    "settings": os.path.join(DATA, "settings.db"),
}
MIN_AGE = 15
ALLOWED_VIDEO_EXTS = {".mp4", ".webm", ".mov", ".mkv"}
MAX_UPLOAD_BYTES = 1024 * 1024 * 1024  # 1 GB; tune for your server/storage.
FAILS = {}

app = Flask(__name__)
secret_file = os.path.join(BASE, ".secret")
if not os.path.exists(secret_file):
    with open(secret_file, "w", encoding="utf-8") as f:
        f.write(secrets.token_hex(32))
with open(secret_file, encoding="utf-8") as f:
    app.secret_key = f.read().strip()

app.config.update(
    SESSION_COOKIE_SAMESITE="Lax",
    SESSION_COOKIE_HTTPONLY=True,
    SESSION_COOKIE_SECURE=os.environ.get("COOKIE_SECURE", "0") == "1",
    MAX_CONTENT_LENGTH=MAX_UPLOAD_BYTES,
)

def connect_db(name):
    conn = sqlite3.connect(DBS[name], timeout=20)
    conn.row_factory = sqlite3.Row
    conn.execute("PRAGMA foreign_keys=ON")
    conn.execute("PRAGMA journal_mode=WAL")
    conn.execute("PRAGMA synchronous=NORMAL")
    conn.execute("PRAGMA busy_timeout=20000")
    return conn

def get_db(name):
    key = "db_" + name
    if key not in g:
        g[key] = connect_db(name)
    return g[key]

@app.teardown_appcontext
def close_dbs(error=None):
    for name in DBS:
        conn = g.pop("db_" + name, None)
        if conn is not None:
            conn.close()

def init_databases():
    # Accounts database
    c = connect_db("accounts")
    c.executescript("""
    CREATE TABLE IF NOT EXISTS users (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        name TEXT NOT NULL,
        phone TEXT NOT NULL UNIQUE,
        age INTEGER NOT NULL,
        pw TEXT NOT NULL,
        admin INTEGER NOT NULL DEFAULT 0,
        created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP
    );
    CREATE INDEX IF NOT EXISTS idx_users_phone ON users(phone);
    CREATE TABLE IF NOT EXISTS api_tokens (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        user_id INTEGER NOT NULL,
        token_hash TEXT NOT NULL UNIQUE,
        created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP,
        FOREIGN KEY(user_id) REFERENCES users(id) ON DELETE CASCADE
    );
    CREATE INDEX IF NOT EXISTS idx_api_tokens_user ON api_tokens(user_id);
    """)
    c.close()

    # Videos database: metadata only. Video binaries remain in uploads/.
    c = connect_db("videos")
    c.executescript("""
    CREATE TABLE IF NOT EXISTS hobbies (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        name TEXT NOT NULL UNIQUE,
        descr TEXT NOT NULL DEFAULT ''
    );
    CREATE TABLE IF NOT EXISTS videos (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        title TEXT NOT NULL,
        descr TEXT NOT NULL DEFAULT '',
        hobby_id INTEGER NOT NULL,
        kind TEXT NOT NULL CHECK(kind IN ('short','long')),
        file TEXT NOT NULL UNIQUE,
        views INTEGER NOT NULL DEFAULT 0,
        created TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP,
        FOREIGN KEY(hobby_id) REFERENCES hobbies(id) ON DELETE RESTRICT
    );
    CREATE INDEX IF NOT EXISTS idx_videos_hobby_kind ON videos(hobby_id, kind, id DESC);
    CREATE INDEX IF NOT EXISTS idx_videos_created ON videos(id DESC);
    """)
    if not c.execute("SELECT 1 FROM hobbies LIMIT 1").fetchone():
        c.executemany("INSERT INTO hobbies(name,descr) VALUES(?,?)", [
            ("الرسم", "تعلّم الرسم بالرصاص والألوان من الصفر."),
            ("العود", "دروس عزف وتدريبات على آلة العود."),
            ("التصوير", "أساسيات التصوير والإضاءة والتكوين."),
            ("الطبخ", "وصفات وتقنيات طبخ بسيطة."),
            ("الشطرنج", "قواعد وخطط وافتتاحيات."),
        ])
    c.commit()
    c.close()

    # Community database: ready for posts, comments, and private messages.
    c = connect_db("community")
    c.executescript("""
    CREATE TABLE IF NOT EXISTS posts (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        user_id INTEGER NOT NULL,
        body TEXT NOT NULL,
        created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP
    );
    CREATE INDEX IF NOT EXISTS idx_posts_created ON posts(id DESC);
    CREATE INDEX IF NOT EXISTS idx_posts_user ON posts(user_id, id DESC);
    CREATE TABLE IF NOT EXISTS messages (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        sender_id INTEGER NOT NULL,
        receiver_id INTEGER NOT NULL,
        body TEXT NOT NULL,
        is_read INTEGER NOT NULL DEFAULT 0,
        created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP
    );
    CREATE INDEX IF NOT EXISTS idx_messages_inbox ON messages(receiver_id, is_read, id DESC);
    CREATE INDEX IF NOT EXISTS idx_messages_thread ON messages(sender_id, receiver_id, id DESC);
    CREATE TABLE IF NOT EXISTS comments (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        post_id INTEGER NOT NULL,
        user_id INTEGER NOT NULL,
        body TEXT NOT NULL,
        created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP
    );
    CREATE INDEX IF NOT EXISTS idx_comments_post ON comments(post_id, id);
    """)
    c.close()

    # Side information / configuration database.
    c = connect_db("settings")
    c.executescript("""
    CREATE TABLE IF NOT EXISTS settings (
        key TEXT PRIMARY KEY,
        value TEXT NOT NULL,
        updated_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP
    );
    CREATE TABLE IF NOT EXISTS notifications (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        user_id INTEGER,
        title TEXT NOT NULL,
        body TEXT NOT NULL DEFAULT '',
        is_read INTEGER NOT NULL DEFAULT 0,
        created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP
    );
    CREATE INDEX IF NOT EXISTS idx_notifications_user ON notifications(user_id, is_read, id DESC);
    """)
    c.execute("INSERT OR IGNORE INTO settings(key,value) VALUES('platform_name','نون')")
    c.execute("INSERT OR IGNORE INTO settings(key,value) VALUES('platform_tagline','مساحتك لاكتشاف ما تحب وتعلّمه')")
    c.commit()
    c.close()

def norm_phone(value):
    value = (value or "").translate(str.maketrans("٠١٢٣٤٥٦٧٨٩", "0123456789"))
    value = re.sub(r"[\s\-]", "", value)
    value = re.sub(r"^(\+963|00963)", "0", value)
    return value if re.fullmatch(r"09\d{8}", value) else None

@app.before_request
def load_user():
    g.user = None
    if session.get("uid"):
        g.user = get_db("accounts").execute(
            "SELECT id,name,phone,age,admin,created_at FROM users WHERE id=?",
            (session["uid"],)
        ).fetchone()
        if g.user is None:
            session.clear()

@app.before_request
def csrf_check():
    if "csrf" not in session:
        session["csrf"] = secrets.token_hex(24)
    if request.method == "POST" and not request.path.startswith("/api/"):
        supplied = request.form.get("csrf", "")
        if not hmac.compare_digest(supplied, session["csrf"]):
            abort(400)

@app.context_processor
def helpers():
    return {"csrf_input": lambda: Markup(
        '<input type="hidden" name="csrf" value="%s">' % session["csrf"]
    )}

@app.after_request
def security_headers(response):
    response.headers["X-Content-Type-Options"] = "nosniff"
    response.headers["X-Frame-Options"] = "DENY"
    response.headers["Referrer-Policy"] = "same-origin"
    response.headers["Permissions-Policy"] = "camera=(), microphone=(), geolocation=()"
    response.headers["Content-Security-Policy"] = (
        "default-src 'self'; style-src 'self' 'unsafe-inline'; "
        "script-src 'self' 'unsafe-inline'; media-src 'self'; frame-ancestors 'none'"
    )
    return response

@app.before_request
def require_login_for_private_pages():
    public_endpoints = {"login", "register", "static"}
    if request.path.startswith("/api/"):
        return None
    if not g.user and request.endpoint not in public_endpoints:
        return redirect(url_for("login", next=request.path))

def login_required(fn):
    @wraps(fn)
    def wrapped(*args, **kwargs):
        if not g.user:
            return redirect(url_for("login"))
        return fn(*args, **kwargs)
    return wrapped

def admin_required(fn):
    @wraps(fn)
    @login_required
    def wrapped(*args, **kwargs):
        if not g.user["admin"]:
            abort(403)
        return fn(*args, **kwargs)
    return wrapped

def video_rows(sql, params=()):
    return get_db("videos").execute(sql, params).fetchall()


# ------------------------- Native Android JSON API -------------------------
import hashlib
from flask import jsonify

def api_error(message, status=400):
    return jsonify({"ok": False, "error": message}), status

def api_user():
    auth = request.headers.get("Authorization", "")
    if not auth.startswith("Bearer "):
        return None
    raw = auth[7:].strip()
    if not raw:
        return None
    digest = hashlib.sha256(raw.encode("utf-8")).hexdigest()
    return get_db("accounts").execute("""
        SELECT u.id,u.name,u.phone,u.age,u.admin,u.created_at
        FROM api_tokens t JOIN users u ON u.id=t.user_id
        WHERE t.token_hash=?
    """, (digest,)).fetchone()

def api_issue_token(user_id):
    raw = secrets.token_urlsafe(36)
    digest = hashlib.sha256(raw.encode("utf-8")).hexdigest()
    c = get_db("accounts")
    c.execute("INSERT INTO api_tokens(user_id,token_hash) VALUES(?,?)", (user_id,digest))
    c.commit()
    return raw

@app.route("/api/v1/health", methods=["GET"])
def api_health():
    return jsonify({"ok": True, "platform": "نون", "api": "v1"})

@app.route("/api/v1/register", methods=["POST"])
def api_register():
    data = request.get_json(silent=True) or {}
    name = str(data.get("name", "")).strip()[:80]
    phone = norm_phone(data.get("phone"))
    password = str(data.get("password", ""))
    try:
        age = int(data.get("age", 0))
    except (TypeError, ValueError):
        age = 0

    accounts = get_db("accounts")
    if not name:
        return api_error("اكتب الاسم.")
    if not phone:
        return api_error("رقم الهاتف يجب أن يكون بصيغة 09XXXXXXXX.")
    if age < MIN_AGE or age > 120:
        return api_error(f"التسجيل متاح للأعمار من {MIN_AGE} سنة.")
    if len(password) < 8:
        return api_error("كلمة المرور يجب أن تكون 8 أحرف على الأقل.")
    if accounts.execute("SELECT 1 FROM users WHERE phone=?", (phone,)).fetchone():
        return api_error("هذا الرقم مسجل من قبل.", 409)

    first = not accounts.execute("SELECT 1 FROM users LIMIT 1").fetchone()
    cur = accounts.execute(
        "INSERT INTO users(name,phone,age,pw,admin) VALUES(?,?,?,?,?)",
        (name, phone, age, generate_password_hash(password), int(first))
    )
    accounts.commit()
    token = api_issue_token(cur.lastrowid)
    return jsonify({"ok": True, "token": token, "user": {
        "id": cur.lastrowid, "name": name, "phone": phone, "age": age, "admin": int(first)
    }}), 201

@app.route("/api/v1/login", methods=["POST"])
def api_login():
    data = request.get_json(silent=True) or {}
    phone = norm_phone(data.get("phone")) or ""
    password = str(data.get("password", ""))
    user = get_db("accounts").execute(
        "SELECT * FROM users WHERE phone=?", (phone,)
    ).fetchone()
    if not user or not check_password_hash(user["pw"], password):
        return api_error("رقم الهاتف أو كلمة المرور غير صحيحة.", 401)
    token = api_issue_token(user["id"])
    return jsonify({"ok": True, "token": token, "user": {
        "id": user["id"], "name": user["name"], "phone": user["phone"],
        "age": user["age"], "admin": user["admin"]
    }})

@app.route("/api/v1/me", methods=["GET"])
def api_me():
    user = api_user()
    if not user:
        return api_error("يلزم تسجيل الدخول.", 401)
    return jsonify({"ok": True, "user": dict(user)})

@app.route("/api/v1/logout", methods=["POST"])
def api_logout():
    auth = request.headers.get("Authorization", "")
    raw = auth[7:].strip() if auth.startswith("Bearer ") else ""
    if raw:
        digest = hashlib.sha256(raw.encode("utf-8")).hexdigest()
        c = get_db("accounts")
        c.execute("DELETE FROM api_tokens WHERE token_hash=?", (digest,))
        c.commit()
    return jsonify({"ok": True})

@app.route("/api/v1/hobbies", methods=["GET"])
def api_hobbies():
    user = api_user()
    if not user:
        return api_error("يلزم تسجيل الدخول.", 401)
    rows = get_db("videos").execute("""
        SELECT h.id,h.name,h.descr,
        (SELECT COUNT(*) FROM videos v WHERE v.hobby_id=h.id) AS video_count
        FROM hobbies h ORDER BY h.id
    """).fetchall()
    return jsonify({"ok": True, "items": [dict(x) for x in rows]})

@app.route("/api/v1/videos", methods=["GET"])
def api_videos():
    user = api_user()
    if not user:
        return api_error("يلزم تسجيل الدخول.", 401)
    rows = get_db("videos").execute("""
        SELECT v.id,v.title,v.descr,v.kind,v.views,v.created,h.name AS hobby
        FROM videos v JOIN hobbies h ON h.id=v.hobby_id
        ORDER BY v.id DESC LIMIT 100
    """).fetchall()
    return jsonify({"ok": True, "items": [dict(x) for x in rows]})

@app.route("/")
def index():
    q = request.args.get("q", "").strip()[:100]
    if q:
        like = f"%{q}%"
        videos = video_rows("""
            SELECT v.*, h.name AS hobby FROM videos v
            JOIN hobbies h ON h.id=v.hobby_id
            WHERE v.title LIKE ? OR v.descr LIKE ? OR h.name LIKE ?
            ORDER BY v.id DESC LIMIT 60
        """, (like, like, like))
        return render_template("index.html", q=q, videos=videos, hobbies=[])
    hobbies = video_rows("""
        SELECT h.*, (SELECT COUNT(*) FROM videos v WHERE v.hobby_id=h.id) AS n
        FROM hobbies h ORDER BY h.id
    """)
    videos = video_rows("""
        SELECT v.*, h.name AS hobby FROM videos v
        JOIN hobbies h ON h.id=v.hobby_id ORDER BY v.id DESC LIMIT 12
    """)
    return render_template("index.html", q="", videos=videos, hobbies=hobbies)

@app.route("/hobby/<int:hid>")
def hobby(hid):
    h = get_db("videos").execute("SELECT * FROM hobbies WHERE id=?", (hid,)).fetchone()
    if not h:
        abort(404)
    shorts = video_rows("""
        SELECT v.*, ? AS hobby FROM videos v
        WHERE hobby_id=? AND kind='short' ORDER BY id DESC LIMIT 100
    """, (h["name"], hid))
    longs = video_rows("""
        SELECT v.*, ? AS hobby FROM videos v
        WHERE hobby_id=? AND kind='long' ORDER BY id DESC LIMIT 100
    """, (h["name"], hid))
    return render_template("hobby.html", h=h, shorts=shorts, longs=longs)

@app.route("/video/<int:vid>")
@login_required
def video(vid):
    v = get_db("videos").execute("""
        SELECT v.*, h.name AS hobby FROM videos v
        JOIN hobbies h ON h.id=v.hobby_id WHERE v.id=?
    """, (vid,)).fetchone()
    if not v:
        abort(404)
    get_db("videos").execute("UPDATE videos SET views=views+1 WHERE id=?", (vid,))
    get_db("videos").commit()
    more = video_rows("""
        SELECT v.*, ? AS hobby FROM videos v
        WHERE hobby_id=? AND id<>? ORDER BY id DESC LIMIT 6
    """, (v["hobby"], v["hobby_id"], vid))
    return render_template("video.html", v=v, more=more)

@app.route("/media/<name>")
@login_required
def media(name):
    # send_from_directory prevents path traversal outside the upload folder.
    return send_from_directory(UPLOADS, name, conditional=True)

@app.route("/register", methods=["GET", "POST"])
def register():
    if g.user:
        return redirect(url_for("index"))
    if request.method == "POST":
        name = request.form.get("name", "").strip()[:80]
        phone = norm_phone(request.form.get("phone"))
        password = request.form.get("pw", "")
        try:
            age = int(request.form.get("age", ""))
        except (TypeError, ValueError):
            age = 0

        accounts = get_db("accounts")
        if not name:
            flash("اكتب اسمك.")
        elif not phone:
            flash("رقم الهاتف لازم يكون بصيغة 09XXXXXXXX.")
        elif age < MIN_AGE or age > 120:
            flash(f"التسجيل متاح للأعمار من {MIN_AGE} سنة.")
        elif len(password) < 8:
            flash("كلمة السر يجب أن تكون 8 أحرف على الأقل.")
        elif accounts.execute("SELECT 1 FROM users WHERE phone=?", (phone,)).fetchone():
            flash("هذا الرقم مسجّل من قبل.")
        else:
            first = not accounts.execute("SELECT 1 FROM users LIMIT 1").fetchone()
            cur = accounts.execute(
                "INSERT INTO users(name,phone,age,pw,admin) VALUES(?,?,?,?,?)",
                (name, phone, age, generate_password_hash(password), int(first))
            )
            accounts.commit()
            session.clear()
            session["uid"] = cur.lastrowid
            session["csrf"] = secrets.token_hex(24)
            return redirect(url_for("index"))
    return render_template("register.html")

@app.route("/login", methods=["GET", "POST"])
def login():
    if g.user:
        return redirect(url_for("index"))
    if request.method == "POST":
        phone = norm_phone(request.form.get("phone")) or ""
        key = f"{request.remote_addr}|{phone}"
        count, last = FAILS.get(key, (0, 0))
        if count >= 5 and time.time() - last < 600:
            flash("محاولات كثيرة. جرّب بعد 10 دقائق.")
            return render_template("login.html")
        user = get_db("accounts").execute(
            "SELECT * FROM users WHERE phone=?", (phone,)
        ).fetchone()
        if user and check_password_hash(user["pw"], request.form.get("pw", "")):
            FAILS.pop(key, None)
            session.clear()
            session["uid"] = user["id"]
            session["csrf"] = secrets.token_hex(24)
            return redirect(request.args.get("next") or url_for("index"))
        FAILS[key] = (count + 1, time.time())
        flash("رقم الهاتف أو كلمة السر غير صحيحة.")
    return render_template("login.html")

@app.route("/logout", methods=["POST"])
@login_required
def logout():
    session.clear()
    return redirect(url_for("login"))

@app.route("/admin")
@admin_required
def admin():
    hobbies = video_rows("SELECT * FROM hobbies ORDER BY name")
    videos = video_rows("""
        SELECT v.*, h.name AS hobby FROM videos v
        JOIN hobbies h ON h.id=v.hobby_id ORDER BY v.id DESC LIMIT 200
    """)
    return render_template("admin.html", hobbies=hobbies, videos=videos)

@app.route("/admin/hobby", methods=["POST"])
@admin_required
def add_hobby():
    name = request.form.get("name", "").strip()[:60]
    descr = request.form.get("descr", "").strip()[:500]
    if name:
        try:
            get_db("videos").execute(
                "INSERT INTO hobbies(name,descr) VALUES(?,?)", (name, descr)
            )
            get_db("videos").commit()
            flash("تمت إضافة الهواية.")
        except sqlite3.IntegrityError:
            flash("هذه الهواية موجودة.")
    return redirect(url_for("admin"))

@app.route("/admin/upload", methods=["POST"])
@admin_required
def upload():
    uploaded = request.files.get("file")
    original = secure_filename(uploaded.filename) if uploaded else ""
    ext = os.path.splitext(original)[1].lower()
    title = request.form.get("title", "").strip()[:150]
    descr = request.form.get("descr", "").strip()[:2000]
    kind = request.form.get("kind")
    hobby_id = request.form.get("hobby_id", type=int)
    hobby = get_db("videos").execute(
        "SELECT id FROM hobbies WHERE id=?", (hobby_id,)
    ).fetchone() if hobby_id else None

    if not uploaded or not original or ext not in ALLOWED_VIDEO_EXTS or not title or kind not in ("short", "long") or not hobby:
        flash("تأكد من العنوان والهواية ونوع الفيديو وصيغة الملف.")
        return redirect(url_for("admin"))

    filename = uuid.uuid4().hex + ext
    path = os.path.join(UPLOADS, filename)
    uploaded.save(path)
    try:
        get_db("videos").execute(
            "INSERT INTO videos(title,descr,hobby_id,kind,file) VALUES(?,?,?,?,?)",
            (title, descr, hobby_id, kind, filename)
        )
        get_db("videos").commit()
    except Exception:
        try:
            os.remove(path)
        except OSError:
            pass
        raise
    flash("تم رفع الفيديو بنجاح.")
    return redirect(url_for("admin"))

@app.route("/admin/delete/<int:vid>", methods=["POST"])
@admin_required
def delete_video(vid):
    conn = get_db("videos")
    video = conn.execute("SELECT file FROM videos WHERE id=?", (vid,)).fetchone()
    if video:
        conn.execute("DELETE FROM videos WHERE id=?", (vid,))
        conn.commit()
        try:
            os.remove(os.path.join(UPLOADS, video["file"]))
        except OSError:
            pass
        flash("تم حذف الفيديو.")
    return redirect(url_for("admin"))

@app.errorhandler(413)
def too_large(error):
    flash("حجم الملف أكبر من الحد المسموح به (1 غيغابايت).")
    return redirect(url_for("admin"))

@app.errorhandler(404)
def not_found(error):
    return render_template("error.html", code=404, message="الصفحة غير موجودة."), 404

@app.errorhandler(403)
def forbidden(error):
    return render_template("error.html", code=403, message="ليس لديك صلاحية للوصول."), 403

init_databases()

if __name__ == "__main__":
    from waitress import serve
    serve(app, host="0.0.0.0", port=int(os.environ.get("PORT", "5000")),
          threads=int(os.environ.get("THREADS", "8")),
          max_request_body_size=MAX_UPLOAD_BYTES)

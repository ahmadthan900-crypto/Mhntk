package com.noon.app

import android.app.Activity
import android.os.Bundle
import android.graphics.Color
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.widget.*
import android.text.InputType
import org.json.JSONArray
import org.json.JSONObject
import java.net.HttpURLConnection
import java.net.URL
import java.io.OutputStreamWriter
import java.util.concurrent.Executors

class MainActivity : Activity() {
    // غيّر هذا العنوان إلى عنوان جهاز الكمبيوتر الذي يعمل عليه Flask.
    // مثال: http://192.168.1.5:5000/api/v1
    private val apiBase = "https://jewelry-catalyst-asin-preventing.trycloudflare.com/api/v1"
    private val worker = Executors.newSingleThreadExecutor()
    private val prefs by lazy { getSharedPreferences("noon_session", MODE_PRIVATE) }
    private var token: String? = null
    private var currentUser = JSONObject()
    private var selectedTab = "home"
    private var hobbies = JSONArray()
    private var videos = JSONArray()

    private val ink = Color.rgb(43, 27, 69)
    private val purple = Color.rgb(91, 48, 145)
    private val violet = Color.rgb(119, 75, 183)
    private val gold = Color.rgb(218, 164, 75)
    private val paper = Color.rgb(250, 247, 242)
    private val white = Color.WHITE
    private val muted = Color.rgb(126, 116, 137)
    private lateinit var root: LinearLayout
    private lateinit var body: LinearLayout
    private lateinit var status: TextView

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.statusBarColor = ink
        window.navigationBarColor = ink
        token = prefs.getString("token", null)
        if (token == null) showLogin() else loadMeThenHome()
    }

    override fun onDestroy() {
        super.onDestroy()
        worker.shutdown()
    }

    private fun dp(v: Int): Int = (v * resources.displayMetrics.density).toInt()
    private fun shape(color: Int, radius: Int = 18, stroke: Int = 0): GradientDrawable =
        GradientDrawable().apply {
            setColor(color); cornerRadius = dp(radius).toFloat()
            if (stroke != 0) setStroke(dp(1), stroke)
        }

    private fun text(value: String, size: Float = 14f, color: Int = ink, bold: Boolean = false): TextView =
        TextView(this).apply {
            text = value; textSize = size; setTextColor(color)
            gravity = Gravity.RIGHT
            if (bold) typeface = Typeface.create("sans-serif", Typeface.BOLD)
            textDirection = View.TEXT_DIRECTION_FIRST_STRONG
            setLineSpacing(dp(2).toFloat(), 1f)
        }

    private fun label(value: String, size: Float = 14f, color: Int = ink, bold: Boolean = false): TextView =
        text(value, size, color, bold).apply {
            setPadding(dp(2), dp(5), dp(2), dp(5))
            layoutParams = LinearLayout.LayoutParams(-1, -2)
        }

    private fun space(height: Int) = View(this).apply {
        layoutParams = LinearLayout.LayoutParams(1, dp(height))
    }

    private fun card(parent: LinearLayout, padding: Int = 16): LinearLayout {
        val box = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(padding), dp(padding), dp(padding), dp(padding))
            background = shape(white, 20, Color.rgb(239, 232, 244))
            layoutParams = LinearLayout.LayoutParams(-1, -2).apply {
                setMargins(0, dp(6), 0, dp(8))
            }
        }
        parent.addView(box)
        return box
    }

    private fun pillButton(title: String, filled: Boolean = true, action: () -> Unit): TextView =
        TextView(this).apply {
            text = title; textSize = 14f; gravity = Gravity.CENTER
            setTextColor(if (filled) white else purple)
            typeface = Typeface.DEFAULT_BOLD
            setPadding(dp(18), dp(12), dp(18), dp(12))
            background = shape(if (filled) purple else Color.rgb(244, 238, 250), 15)
            setOnClickListener { action() }
        }

    private fun edit(hintText: String, password: Boolean = false, numeric: Boolean = false): EditText =
        EditText(this).apply {
            hint = hintText; textSize = 15f; setSingleLine(true)
            textDirection = View.TEXT_DIRECTION_FIRST_STRONG
            inputType = when {
                password -> InputType.TYPE_CLASS_TEXT or InputType.TYPE_TEXT_VARIATION_PASSWORD
                numeric -> InputType.TYPE_CLASS_NUMBER
                else -> InputType.TYPE_CLASS_TEXT
            }
            setPadding(dp(15), 0, dp(15), 0)
            background = shape(Color.rgb(248, 245, 250), 14, Color.rgb(231, 222, 239))
            layoutParams = LinearLayout.LayoutParams(-1, dp(54)).apply {
                setMargins(0, dp(6), 0, dp(6))
            }
        }

    private fun pageFrame(title: String, showNav: Boolean = true) {
        root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setBackgroundColor(paper)
            layoutDirection = View.LAYOUT_DIRECTION_LTR
        }
        val header = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            setPadding(dp(18), dp(12), dp(18), dp(12))
            setBackgroundColor(white)
        }
        val mark = TextView(this).apply {
            text = "ن"; textSize = 28f; gravity = Gravity.CENTER
            typeface = Typeface.create("sans-serif", Typeface.BOLD)
            setTextColor(white); background = shape(purple, 14)
            layoutParams = LinearLayout.LayoutParams(dp(44), dp(44))
        }
        header.addView(mark)
        val heading = TextView(this).apply {
            text = title; textSize = 20f; setTextColor(ink)
            typeface = Typeface.DEFAULT_BOLD; gravity = Gravity.RIGHT or Gravity.CENTER_VERTICAL
            setPadding(dp(12), 0, 0, 0)
            layoutParams = LinearLayout.LayoutParams(0, -2, 1f)
        }
        header.addView(heading)
        val search = TextView(this).apply {
            text = "⌕"; textSize = 28f; gravity = Gravity.CENTER
            setTextColor(purple); background = shape(Color.rgb(246, 241, 249), 14)
            layoutParams = LinearLayout.LayoutParams(dp(42), dp(42))
            setOnClickListener { showDiscover() }
        }
        if (showNav) header.addView(search)
        root.addView(header)
        val scroller = ScrollView(this).apply {
            isFillViewport = true
            layoutParams = LinearLayout.LayoutParams(-1, 0, 1f)
        }
        body = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            layoutDirection = View.LAYOUT_DIRECTION_LTR
            setPadding(dp(18), dp(16), dp(18), dp(18))
        }
        scroller.addView(body)
        root.addView(scroller)
        if (showNav && token != null) root.addView(bottomNav())
        setContentView(root)
    }

    private fun bottomNav(): View {
        val bar = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER
            setBackgroundColor(white)
            setPadding(dp(5), dp(8), dp(5), dp(8))
        }
        val items = listOf(
            Triple("home", "⌂", "الرئيسية"),
            Triple("discover", "⌕", "اكتشف"),
            Triple("create", "+", "أضف"),
            Triple("videos", "▷", "فيديو"),
            Triple("profile", "◉", "حسابي")
        )
        items.forEach { (id, icon, title) ->
            val active = selectedTab == id
            val item = LinearLayout(this).apply {
                orientation = LinearLayout.VERTICAL; gravity = Gravity.CENTER
                setPadding(dp(3), dp(2), dp(3), dp(2))
                layoutParams = LinearLayout.LayoutParams(0, -2, 1f)
                setOnClickListener {
                    selectedTab = id
                    when (id) {
                        "home" -> showHome()
                        "discover" -> showDiscover()
                        "create" -> showCreate()
                        "videos" -> showVideos()
                        "profile" -> showProfile()
                    }
                }
            }
            item.addView(TextView(this).apply {
                text = icon; textSize = if (id == "create") 26f else 23f
                gravity = Gravity.CENTER; setTextColor(if (active) purple else muted)
                if (id == "create") {
                    background = shape(purple, 18); setTextColor(white)
                    layoutParams = LinearLayout.LayoutParams(dp(42), dp(36))
                }
            })
            item.addView(TextView(this).apply {
                text = title; textSize = 10.5f; gravity = Gravity.CENTER
                setTextColor(if (active) purple else muted)
                setPadding(0, dp(3), 0, 0)
            })
            bar.addView(item)
        }
        return bar
    }

    private fun showLogin() {
        pageFrame("أهلاً بك في نون", false)
        body.gravity = Gravity.CENTER_HORIZONTAL
        body.addView(space(28))
        val logo = TextView(this).apply {
            text = "ن"; textSize = 58f; gravity = Gravity.CENTER
            typeface = Typeface.create("sans-serif", Typeface.BOLD)
            setTextColor(white); background = shape(purple, 28)
            layoutParams = LinearLayout.LayoutParams(dp(112), dp(112))
        }
        body.addView(logo)
        body.addView(space(18))
        body.addView(label("مساحتك لاكتشاف ما تحب ومشاركة شغفك", 16f, muted).apply { gravity = Gravity.CENTER })
        body.addView(space(22))
        val form = card(body, 18)
        form.addView(label("تسجيل الدخول", 21f, ink, true))
        form.addView(space(8))
        val phone = edit("رقم الهاتف")
        val password = edit("كلمة المرور", password = true)
        form.addView(phone); form.addView(password)
        val msg = label("", 13f, Color.RED)
        form.addView(msg)
        form.addView(space(8))
        form.addView(pillButton("دخول إلى نون") {
            val p = phone.text.toString().trim()
            val pw = password.text.toString()
            if (p.isBlank() || pw.isBlank()) { msg.text = "أدخل رقم الهاتف وكلمة المرور."; return@pillButton }
            msg.setTextColor(purple); msg.text = "جارٍ التحقق من بياناتك..."
            postJson("/login", JSONObject().put("phone", p).put("password", pw)) { result, error ->
                if (error != null) { msg.setTextColor(Color.RED); msg.text = error }
                else saveSession(result!!)
            }
        })
        body.addView(space(12))
        val register = pillButton("إنشاء حساب جديد", false) { showRegister() }
        body.addView(register)
        body.addView(space(18))
        body.addView(label("اكتشف الهوايات والمحتوى وتواصل مع مجتمعك", 12f, muted).apply { gravity = Gravity.CENTER })
    }

    private fun showRegister() {
        pageFrame("حساب جديد", false)
        val form = card(body)
        form.addView(label("انضم إلى مجتمع نون", 21f, ink, true))
        form.addView(label("أنشئ حسابك لتبدأ اكتشاف المحتوى.", 13f, muted))
        val name = edit("الاسم")
        val phone = edit("رقم الهاتف")
        val age = edit("العمر", numeric = true)
        val pass = edit("كلمة المرور", password = true)
        form.addView(name); form.addView(phone); form.addView(age); form.addView(pass)
        val msg = label("", 13f, Color.RED); form.addView(msg)
        form.addView(pillButton("إنشاء الحساب") {
            val a = age.text.toString().toIntOrNull()
            if (name.text.isBlank() || phone.text.isBlank() || a == null || pass.text.length < 8) {
                msg.text = "أكمل الحقول، واجعل كلمة المرور 8 أحرف على الأقل."; return@pillButton
            }
            msg.setTextColor(purple); msg.text = "جارٍ إنشاء الحساب..."
            val data = JSONObject().put("name", name.text.toString().trim())
                .put("phone", phone.text.toString().trim()).put("age", a)
                .put("password", pass.text.toString())
            postJson("/register", data) { result, error ->
                if (error != null) { msg.setTextColor(Color.RED); msg.text = error }
                else saveSession(result!!)
            }
        })
        body.addView(space(10))
        body.addView(pillButton("لدي حساب — تسجيل الدخول", false) { showLogin() })
    }

    private fun saveSession(result: JSONObject) {
        token = result.optString("token")
        prefs.edit().putString("token", token).apply()
        loadMeThenHome()
    }

    private fun loadMeThenHome() {
        getJson("/me") { result, error ->
            if (error == null && result != null) currentUser = result.optJSONObject("user") ?: result
            showHome()
        }
    }

    private fun showHome() {
        selectedTab = "home"
        pageFrame("الرئيسية")
        val hero = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(20), dp(22), dp(20), dp(22))
            background = GradientDrawable(
                GradientDrawable.Orientation.RIGHT_LEFT,
                intArrayOf(Color.rgb(68, 35, 105), Color.rgb(123, 76, 167))
            ).apply { cornerRadius = dp(24).toFloat() }
        }
        hero.addView(label("مرحباً بك في نون ✨", 22f, white, true))
        hero.addView(label("مساحة تجمع اهتماماتك، أفكارك، ومواهبك.", 14f, Color.rgb(239, 228, 249)))
        hero.addView(space(10))
        hero.addView(pillButton("اكتشف ما يناسبك  ←", false) { showDiscover() })
        body.addView(hero)
        body.addView(space(12))
        body.addView(label("استكشف الأقسام", 19f, ink, true))
        body.addView(label("اختر هواية وابدأ رحلتك في التعلّم.", 13f, muted))
        val chips = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL }
        listOf("📚 قراءة", "🎨 فن", "💻 تقنية", "⚽ رياضة").forEach { c ->
            val v = TextView(this).apply {
                text = c; textSize = 12f; setTextColor(purple); gravity = Gravity.CENTER
                setPadding(dp(10), dp(10), dp(10), dp(10)); background = shape(Color.rgb(242, 235, 248), 16)
                layoutParams = LinearLayout.LayoutParams(0, -2, 1f).apply { setMargins(dp(2), dp(5), dp(2), dp(5)) }
                setOnClickListener { showDiscover() }
            }
            chips.addView(v)
        }
        body.addView(chips)
        body.addView(space(8))
        body.addView(label("أحدث المحتوى", 19f, ink, true))
        val loading = card(body)
        loading.addView(label("جارٍ تحميل المحتوى...", 14f, muted))
        getJson("/hobbies") { h, he ->
            if (he == null && h != null) hobbies = h.optJSONArray("items") ?: JSONArray()
            getJson("/videos") { v, ve ->
                if (ve == null && v != null) videos = v.optJSONArray("items") ?: JSONArray()
                loading.removeAllViews()
                if (hobbies.length() == 0 && videos.length() == 0) {
                    loading.addView(label("لا يوجد محتوى منشور حالياً. عد لاحقاً لاكتشاف الجديد.", 14f, muted))
                } else {
                    for (i in 0 until minOf(videos.length(), 4)) {
                        val item = videos.optJSONObject(i) ?: continue
                        loading.addView(label("▶  ${item.optString("title", "محتوى جديد")}", 15f, ink, true))
                        loading.addView(label("${item.optString("hobby", "هواية")}  •  ${item.optInt("views")} مشاهدة", 12f, muted))
                        loading.addView(space(8))
                    }
                    if (hobbies.length() > 0) loading.addView(label("عدد الهوايات المتاحة: ${hobbies.length()}", 12f, purple, true))
                }
            }
        }
    }

    private fun showDiscover() {
        selectedTab = "discover"
        pageFrame("اكتشف")
        body.addView(label("اعثر على شيء يلهمك", 22f, ink, true))
        body.addView(label("تصفّح الهوايات والأقسام المتاحة في نون.", 14f, muted))
        body.addView(space(10))
        val list = card(body)
        list.addView(label("الهوايات", 18f, ink, true))
        getJson("/hobbies") { result, error ->
            list.removeAllViews()
            list.addView(label("الهوايات", 18f, ink, true))
            if (error != null) list.addView(label(error, 13f, Color.RED))
            else {
                hobbies = result!!.optJSONArray("items") ?: JSONArray()
                if (hobbies.length() == 0) list.addView(label("لا توجد هوايات منشورة حالياً.", 14f, muted))
                for (i in 0 until hobbies.length()) {
                    val h = hobbies.optJSONObject(i) ?: continue
                    val row = LinearLayout(this).apply {
                        orientation = LinearLayout.VERTICAL; setPadding(0, dp(10), 0, dp(10))
                    }
                    row.addView(label("✦  ${h.optString("name")}", 16f, purple, true))
                    val desc = h.optString("descr")
                    if (desc.isNotBlank()) row.addView(label(desc, 13f, muted))
                    row.addView(label("${h.optInt("video_count")} فيديو", 11f, gold, true))
                    list.addView(row)
                    list.addView(View(this).apply { setBackgroundColor(Color.rgb(241, 235, 244)); layoutParams = LinearLayout.LayoutParams(-1, dp(1)) })
                }
            }
        }
        body.addView(space(10))
        body.addView(pillButton("مشاهدة الفيديوهات  ▷", true) { showVideos() })
    }

    private fun showVideos() {
        selectedTab = "videos"
        pageFrame("الفيديوهات")
        body.addView(label("محتوى يلهمك", 22f, ink, true))
        body.addView(label("شاهد ما يشاركه مجتمع نون.", 14f, muted))
        val list = card(body)
        list.addView(label("أحدث الفيديوهات", 18f, ink, true))
        getJson("/videos") { result, error ->
            list.removeAllViews()
            list.addView(label("أحدث الفيديوهات", 18f, ink, true))
            if (error != null) list.addView(label(error, 13f, Color.RED))
            else {
                videos = result!!.optJSONArray("items") ?: JSONArray()
                if (videos.length() == 0) list.addView(label("لا توجد فيديوهات منشورة بعد.", 14f, muted))
                for (i in 0 until videos.length()) {
                    val v = videos.optJSONObject(i) ?: continue
                    val tile = LinearLayout(this).apply {
                        orientation = LinearLayout.VERTICAL
                        setPadding(dp(14), dp(14), dp(14), dp(14))
                        background = shape(Color.rgb(248, 244, 250), 16)
                        layoutParams = LinearLayout.LayoutParams(-1, -2).apply { setMargins(0, dp(6), 0, dp(6)) }
                    }
                    tile.addView(label("▶  ${v.optString("title", "فيديو")}", 16f, ink, true))
                    tile.addView(label("الهواية: ${v.optString("hobby", "عام")}", 12f, muted))
                    tile.addView(label("${v.optInt("views")} مشاهدة", 11f, gold, true))
                    list.addView(tile)
                }
            }
        }
    }

    private fun showCreate() {
        selectedTab = "create"
        pageFrame("شاركنا إبداعك")
        val box = card(body)
        box.addView(label("أضف محتواك إلى نون", 21f, ink, true))
        box.addView(label("يمكنك استكشاف المحتوى المنشور حالياً. نشر المحتوى من حسابات المستخدمين غير متاح في واجهة API الحالية، لذلك تتم إدارة النشر من لوحة الإدارة.", 14f, muted))
        box.addView(space(12))
        box.addView(pillButton("اذهب إلى الفيديوهات", true) { showVideos() })
        box.addView(space(8))
        box.addView(pillButton("استكشف الهوايات", false) { showDiscover() })
    }

    private fun showProfile() {
        selectedTab = "profile"
        pageFrame("حسابي")
        val profile = card(body)
        val avatar = TextView(this).apply {
            text = "ن"; textSize = 34f; gravity = Gravity.CENTER
            setTextColor(white); background = shape(purple, 40)
            layoutParams = LinearLayout.LayoutParams(dp(76), dp(76)).apply { gravity = Gravity.CENTER }
        }
        profile.addView(avatar)
        profile.addView(space(8))
        profile.addView(label(currentUser.optString("name", "عضو نون"), 20f, ink, true).apply { gravity = Gravity.CENTER })
        profile.addView(label(currentUser.optString("phone", ""), 13f, muted).apply { gravity = Gravity.CENTER })
        profile.addView(space(12))
        profile.addView(label("مرحباً بك في مساحتك الشخصية. يمكنك متابعة الهوايات والفيديوهات من أقسام التطبيق.", 13f, muted))
        body.addView(profile)
        val settings = card(body)
        settings.addView(label("إعدادات الحساب", 17f, ink, true))
        settings.addView(label("الجلسة محفوظة على هذا الجهاز.", 13f, muted))
        settings.addView(space(8))
        settings.addView(pillButton("تسجيل الخروج", false) {
            val old = token
            token = null
            prefs.edit().remove("token").apply()
            if (old != null) postJson("/logout", JSONObject(), old) { _, _ -> }
            showLogin()
        })
    }

    private fun postJson(path: String, data: JSONObject, auth: String? = token,
                         done: (JSONObject?, String?) -> Unit) = request("POST", path, data, auth, done)

    private fun getJson(path: String, done: (JSONObject?, String?) -> Unit) = request("GET", path, null, token, done)

    private fun request(method: String, path: String, data: JSONObject?, auth: String?,
                        done: (JSONObject?, String?) -> Unit) {
        worker.execute {
            var conn: HttpURLConnection? = null
            try {
                conn = (URL(apiBase + path).openConnection() as HttpURLConnection).apply {
                    requestMethod = method; connectTimeout = 20000; readTimeout = 25000
                    setRequestProperty("Accept", "application/json")
                    setRequestProperty("User-Agent", "NoonAndroid/1.2")
                    setRequestProperty("Cache-Control", "no-cache")
                    setRequestProperty("Connection", "close")
                    if (auth != null) setRequestProperty("Authorization", "Bearer $auth")
                    if (data != null) {
                        doOutput = true
                        setRequestProperty("Content-Type", "application/json; charset=utf-8")
                        OutputStreamWriter(outputStream, Charsets.UTF_8).use { it.write(data.toString()) }
                    }
                }
                val code = conn.responseCode
                val stream = if (code in 200..299) conn.inputStream else conn.errorStream
                val bodyText = stream?.bufferedReader(Charsets.UTF_8)?.use { it.readText() } ?: "{}"
                val json = try { JSONObject(bodyText) } catch (_: Exception) { null }
                runOnUiThread {
                    if (json == null) {
                        val preview = bodyText.replace("\n", " ").take(120)
                        done(null, "استجابة غير متوقعة من السيرفر (HTTP $code): $preview")
                    } else if (code in 200..299 && json.optBoolean("ok", false)) {
                        done(json, null)
                    } else {
                        done(null, json.optString("error", "حدث خطأ في الاتصال ($code)."))
                    }
                }
            } catch (e: Exception) {
                val reason = e.localizedMessage ?: e.javaClass.simpleName
                runOnUiThread { done(null, "تعذر الاتصال بالسيرفر: $reason") }
            } finally { conn?.disconnect() }
        }
    }
}

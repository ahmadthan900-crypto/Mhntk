package com.noon.app

import android.app.Activity
import android.os.Bundle
import android.graphics.Color
import android.view.Gravity
import android.view.View
import android.widget.*
import org.json.JSONObject
import org.json.JSONArray
import java.net.HttpURLConnection
import java.net.URL
import java.io.OutputStreamWriter
import java.util.concurrent.Executors

class MainActivity : Activity() {
    // غيّر العنوان إلى عنوان الكمبيوتر على الشبكة، مثال: http://192.168.1.5:5000
    // لا تستخدم localhost عند تشغيل التطبيق على هاتف حقيقي.
    private val apiBase = "http://192.168.1.5:5000/api/v1"
    private val worker = Executors.newSingleThreadExecutor()
    private val prefs by lazy { getSharedPreferences("noon_session", MODE_PRIVATE) }
    private lateinit var root: LinearLayout
    private var token: String? = null
    private val purple = Color.rgb(91, 61, 160)

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        token = prefs.getString("token", null)
        if (token == null) showLogin() else loadHome()
    }

    private fun setup(title: String) {
        root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(28, 28, 28, 24)
            setBackgroundColor(Color.rgb(247, 245, 251))
        }
        val header = TextView(this).apply {
            text = title
            textSize = 27f
            setTextColor(purple)
            gravity = Gravity.CENTER
            setPadding(8, 18, 8, 22)
            typeface = android.graphics.Typeface.DEFAULT_BOLD
        }
        root.addView(header)
        setContentView(root)
    }

    private fun field(hint: String, password: Boolean = false): EditText {
        return EditText(this).apply {
            this.hint = hint
            textSize = 16f
            setSingleLine(true)
            if (password) inputType = 129
            setPadding(18, 8, 18, 8)
            background = android.graphics.drawable.GradientDrawable().apply {
                setColor(Color.WHITE); cornerRadius = 22f
                setStroke(1, Color.rgb(220, 214, 234))
            }
            val lp = LinearLayout.LayoutParams(-1, 54)
            lp.setMargins(0, 7, 0, 7)
            layoutParams = lp
        }
    }

    private fun button(label: String, action: () -> Unit): Button {
        return Button(this).apply {
            text = label
            isAllCaps = false
            textSize = 16f
            setTextColor(Color.WHITE)
            backgroundTintList = android.content.res.ColorStateList.valueOf(purple)
            setOnClickListener { action() }
            val lp = LinearLayout.LayoutParams(-1, 52)
            lp.setMargins(0, 8, 0, 8)
            layoutParams = lp
        }
    }

    private fun showLogin() {
        setup("نون")
        val subtitle = TextView(this).apply {
            text = "مساحتك لاكتشاف ما تحب وتعلّمه"
            textSize = 15f; gravity = Gravity.CENTER
            setTextColor(Color.DKGRAY)
        }
        root.addView(subtitle)
        val phone = field("رقم الهاتف 09XXXXXXXX")
        val pass = field("كلمة المرور", true)
        root.addView(phone); root.addView(pass)
        val status = TextView(this).apply { textSize = 14f; setTextColor(Color.RED) }
        root.addView(status)
        root.addView(button("تسجيل الدخول") {
            val p = phone.text.toString().trim()
            val pw = pass.text.toString()
            if (p.isBlank() || pw.isBlank()) { status.text = "أدخل رقم الهاتف وكلمة المرور."; return@button }
            status.setTextColor(purple); status.text = "جارٍ تسجيل الدخول..."
            postJson("/login", JSONObject().put("phone", p).put("password", pw)) { result, error ->
                if (error != null) status.text = error
                else {
                    token = result!!.optString("token")
                    prefs.edit().putString("token", token).apply()
                    loadHome()
                }
            }
        })
        root.addView(button("إنشاء حساب") { showRegister() })
        root.addView(TextView(this).apply {
            text = "تأكد أن السيرفر يعمل على الكمبيوتر وأن عنوانه مضبوط داخل MainActivity.kt"
            textSize = 12f; setTextColor(Color.GRAY)
        })
    }

    private fun showRegister() {
        setup("إنشاء حساب نون")
        val name = field("الاسم")
        val phone = field("رقم الهاتف 09XXXXXXXX")
        val age = field("العمر")
        val pass = field("كلمة المرور (8 أحرف على الأقل)", true)
        root.addView(name); root.addView(phone); root.addView(age); root.addView(pass)
        val status = TextView(this).apply { setTextColor(Color.RED) }
        root.addView(status)
        root.addView(button("إنشاء الحساب") {
            val ageNum = age.text.toString().toIntOrNull()
            if (ageNum == null) { status.text = "أدخل عمراً صحيحاً."; return@button }
            val data = JSONObject().put("name", name.text.toString())
                .put("phone", phone.text.toString()).put("age", ageNum)
                .put("password", pass.text.toString())
            status.setTextColor(purple); status.text = "جارٍ إنشاء الحساب..."
            postJson("/register", data) { result, error ->
                if (error != null) status.text = error
                else {
                    token = result!!.optString("token")
                    prefs.edit().putString("token", token).apply()
                    loadHome()
                }
            }
        })
        root.addView(button("العودة لتسجيل الدخول") { showLogin() })
    }

    private fun loadHome() {
        setup("نون")
        root.addView(TextView(this).apply {
            text = "أهلاً بك في منصتك"
            textSize = 18f; setTextColor(Color.DKGRAY); gravity = Gravity.CENTER
        })
        root.addView(button("تحديث المحتوى") { loadHome() })
        root.addView(button("تسجيل الخروج") {
            val old = token
            token = null
            prefs.edit().remove("token").apply()
            if (old != null) postJson("/logout", JSONObject(), auth = old) { _, _ -> }
            showLogin()
        })
        val content = TextView(this).apply {
            text = "جارٍ تحميل الهوايات والفيديوهات..."
            textSize = 15f; setTextColor(Color.DKGRAY)
        }
        root.addView(content)
        getJson("/hobbies") { hobbies, error ->
            if (error != null) { content.text = error; return@getJson }
            val hobbyItems = hobbies!!.optJSONArray("items") ?: JSONArray()
            val lines = StringBuilder("الهوايات\n\n")
            for (i in 0 until hobbyItems.length()) {
                val h = hobbyItems.getJSONObject(i)
                lines.append("• ").append(h.optString("name"))
                    .append(" — ").append(h.optInt("video_count")).append(" فيديو\n")
                val desc = h.optString("descr")
                if (desc.isNotBlank()) lines.append(desc).append("\n")
                lines.append("\n")
            }
            getJson("/videos") { videos, videoError ->
                if (videoError != null) {
                    content.text = lines.toString() + "\n" + videoError
                } else {
                    lines.append("\nأحدث الفيديوهات\n\n")
                    val arr = videos!!.optJSONArray("items") ?: JSONArray()
                    if (arr.length() == 0) lines.append("لا توجد فيديوهات منشورة حالياً.")
                    for (i in 0 until arr.length()) {
                        val v = arr.getJSONObject(i)
                        lines.append("▶ ").append(v.optString("title"))
                            .append("\nالهواية: ").append(v.optString("hobby"))
                            .append(" | المشاهدات: ").append(v.optInt("views")).append("\n\n")
                    }
                    content.text = lines.toString()
                }
            }
        }
    }

    private fun postJson(path: String, data: JSONObject, auth: String? = token,
                         done: (JSONObject?, String?) -> Unit) {
        request("POST", path, data, auth, done)
    }

    private fun getJson(path: String, done: (JSONObject?, String?) -> Unit) {
        request("GET", path, null, token, done)
    }

    private fun request(method: String, path: String, data: JSONObject?, auth: String?,
                        done: (JSONObject?, String?) -> Unit) {
        worker.execute {
            var conn: HttpURLConnection? = null
            try {
                conn = (URL(apiBase + path).openConnection() as HttpURLConnection).apply {
                    requestMethod = method
                    connectTimeout = 10000
                    readTimeout = 15000
                    setRequestProperty("Accept", "application/json")
                    if (auth != null) setRequestProperty("Authorization", "Bearer $auth")
                    if (data != null) {
                        doOutput = true
                        setRequestProperty("Content-Type", "application/json; charset=utf-8")
                        OutputStreamWriter(outputStream, Charsets.UTF_8).use { it.write(data.toString()) }
                    }
                }
                val code = conn.responseCode
                val stream = if (code in 200..299) conn.inputStream else conn.errorStream
                val body = stream?.bufferedReader(Charsets.UTF_8)?.use { it.readText() } ?: "{}"
                val json = JSONObject(body)
                runOnUiThread {
                    if (code in 200..299 && json.optBoolean("ok", false)) done(json, null)
                    else done(null, json.optString("error", "حدث خطأ في الاتصال ($code)."))
                }
            } catch (e: Exception) {
                runOnUiThread { done(null, "تعذر الاتصال بالسيرفر. تحقق من العنوان وتشغيل الكمبيوتر.") }
            } finally { conn?.disconnect() }
        }
    }
}

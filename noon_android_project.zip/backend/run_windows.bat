@echo off
cd /d "%~dp0"
echo Installing/checking server requirements...
python -m pip install -r requirements.txt
if errorlevel 1 goto failed
echo.
echo Starting Noon server on http://127.0.0.1:5000
python app.py
goto end
:failed
echo.
echo Server setup failed. Read the error above.
:end
echo.
pause
